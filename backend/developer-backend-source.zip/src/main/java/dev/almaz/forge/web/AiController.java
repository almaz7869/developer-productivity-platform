package dev.almaz.forge.web;

import dev.almaz.forge.data.AiSessionRepository;
import dev.almaz.forge.domain.AiSession;
import dev.almaz.forge.service.AiService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController @RequestMapping("/api/ai")
public class AiController {
    private final AiService ai;
    private final AiSessionRepository sessions;
    public AiController(AiService ai, AiSessionRepository sessions) { this.ai = ai; this.sessions = sessions; }

    public record Request(@NotBlank String mode, String language,
                          @NotBlank @Size(max = 30000) String code) {}

    @GetMapping("/sessions")
    public List<AiSession> sessions() { return sessions.findByOwnerOrderByIdDesc("demo"); }

    @PostMapping("/analyze")
    public Map<String, Object> analyze(@RequestBody @Valid Request request) {
        String language = request.language() == null ? "Java" : request.language();
        String result = ai.analyze(request.mode(), language, request.code());
        AiSession session = sessions.save(new AiSession(request.mode(), request.code(), result, LocalDateTime.now()));
        return Map.of("analysis", result, "session", session);
    }
}
